from flask import Flask, render_template
from threading import Thread

app = Flask(__name__)
@app.route('/')
def index():
    return "Alive"

def run():
    app.run(host='46.4.113.153',port=7014)

def keep_alive():
    t = Thread(target=run)
    t.start()    